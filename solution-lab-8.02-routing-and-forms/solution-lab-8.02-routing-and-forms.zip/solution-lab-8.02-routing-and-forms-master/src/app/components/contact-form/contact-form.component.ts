import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {

  name: string = ''
  occupation: string = ''
  email: string = ''
  subject: string = ''
  content: string = ''

  submited: boolean = false

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(): void {
    this.submited = true
  }
}
