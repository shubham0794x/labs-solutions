package com.ironhack.lab708.service.interfaces;

import com.ironhack.lab708.model.Employee;

import java.util.List;

public interface IEmployeeService {
    List<Employee> getEmployees();

    void delete(Long id);
}
