package com.ironhack.lab708;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab708Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab708Application.class, args);

    }

}
