package com.ironhack.lab708.controller.impl;

import com.ironhack.lab708.controller.interfaces.IEmployeeController;
import com.ironhack.lab708.model.Employee;
import com.ironhack.lab708.service.interfaces.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeController implements IEmployeeController {

    @Autowired
    private IEmployeeService employeeService;


    @GetMapping("/employees")
    public List<Employee> getEmployees() {
        return employeeService.getEmployees();
    }

    @DeleteMapping("/employee/{id}")
    public void delete(@PathVariable Long id) {
        employeeService.delete(id);
    }
}
