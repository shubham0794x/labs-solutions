package com.ironhack.lab708.controller.interfaces;

import com.ironhack.lab708.model.Employee;

import java.util.List;

public interface IEmployeeController {

    List<Employee> getEmployees();

    void delete(Long id);
}
