import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Employee } from '../models/employee';
import { Employees, EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-item-dropdown',
  templateUrl: './item-dropdown.component.html',
  styleUrls: ['./item-dropdown.component.css']
})
export class ItemDropdownComponent implements OnInit {

  @Input()
  employeeInfo!: Employees;

  @Input()
  index!: number;

  @Output()
  deleteEmployeeEvent = new EventEmitter();

  @Output()
  deleteElementEvent = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  delete(index: number, id: number): void {
    this.deleteElementEvent.emit(index);
    this.deleteEmployeeEvent.emit(id);
  }

}
