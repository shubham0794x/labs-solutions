import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colorblind',
  templateUrl: './colorblind.component.html',
  styleUrls: ['./colorblind.component.css']
})
export class ColorblindComponent implements OnInit {
  bgColor1:string = '#52796F' 
  ftColor1:string = '#b5179e'

  bgColor2:string = '#9d0208'
  ftColor2:string = '#65743a'

  bgColor3:string = '#b5179e'
  ftColor3:string = '#aa5500'

  colorModeMessage:string = "OFF"

  colorblindFriendly:boolean = false

  constructor() { }

  ngOnInit(): void {
  }

  swapColors(): void {
    if(!this.colorblindFriendly) {
      this.bgColor1 = '#FFC20A' 
      this.ftColor1 = '#0C7BDC'

      this.bgColor2 = '#1AFF1A'
      this.ftColor2 = '#4B0092'

      this.bgColor3 = '#FEFE62'
      this.ftColor3 = '#D35FB7'

      this.colorblindFriendly = true;
      this.colorModeMessage = 'ON'
    } else {
      this.bgColor1 = '#52796F' 
      this.ftColor1 = '#b5179e'

      this.bgColor2 = '#9d0208'
      this.ftColor2 = '#65743a'

      this.bgColor3 = '#b5179e'
      this.ftColor3 = '#aa5500'

      this.colorblindFriendly = false;
      this.colorModeMessage = 'OFF'
    }
  }

  swapBgAndTextColors1(): void{
    let temp = this.bgColor1;
    this.bgColor1 = this.ftColor1;
    this.ftColor1 = temp;
  }

  swapBgAndTextColors2(): void{
    let temp = this.bgColor2;
    this.bgColor2 = this.ftColor2;
    this.ftColor2 = temp;
  }

  swapBgAndTextColors3(): void{
    let temp = this.bgColor3;
    this.bgColor3 = this.ftColor3;
    this.ftColor3 = temp;
  }
}
