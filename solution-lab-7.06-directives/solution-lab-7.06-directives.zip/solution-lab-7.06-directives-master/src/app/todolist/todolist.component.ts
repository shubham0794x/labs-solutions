import { Component, HostListener, OnInit } from '@angular/core';
import { Todoitem } from 'src/app/models/todoitem';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css']
})
export class TodolistComponent implements OnInit {

  todoList: Todoitem[] = [new Todoitem('Ir a correr', false)];
  addItemText: string = '';
  completedColor: string = 'green';
  posponeList: Todoitem[] = [];

  constructor() { }

  ngOnInit(): void {
  }

  deleteElement(index:number): void {
    this.todoList.splice(index, 1);
  }

  posponeElement(index:number): void {
    this.posponeList.push(this.todoList[index]);
    this.todoList.splice(index, 1);
  }

  addItem(): void {
    if(this.addItemText !== '' && this.todoList.filter(element => element.name === this.addItemText).length === 0) {
      this.todoList.push(new Todoitem(this.addItemText, false));
    }
  }
 
  restore(): void {
    for(let item of this.posponeList) {
      this.todoList.push(item);
    }
    this.posponeList.splice(0);
  }

  clear(): void {
    this.todoList = this.todoList.filter(element => element.isCompleted === false)
  }

}
