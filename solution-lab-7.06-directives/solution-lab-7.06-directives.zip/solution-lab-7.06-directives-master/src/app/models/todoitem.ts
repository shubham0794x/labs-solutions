export class Todoitem {

    constructor(
        private _name: string,
        private _isCompleted: boolean
    ){}

    
    public get name() : string {
        return this._name;
    }

    
    public get isCompleted() : boolean {
        return this._isCompleted;
    }
    
    
    public set name(name : string) {
        this._name = name;
    }

    
    public set isCompleted(isCompleted : boolean) {
        this._isCompleted = isCompleted;
    }
    
}
