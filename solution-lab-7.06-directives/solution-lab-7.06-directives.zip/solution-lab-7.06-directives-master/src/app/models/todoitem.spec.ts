import { Todoitem } from './todoitem';

describe('Todoitem', () => {
  it('should create an instance', () => {
    expect(new Todoitem()).toBeTruthy();
  });
});
