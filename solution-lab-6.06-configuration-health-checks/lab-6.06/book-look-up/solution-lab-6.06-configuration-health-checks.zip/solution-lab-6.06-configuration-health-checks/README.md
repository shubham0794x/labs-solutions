# Lab 6.06

<br><br>

### Instructions

<br>

- Create a new GitHub repository named `Enterprise-Java-Development-6.06`
- Add your instructor and the class graders to your repository and ensure that your repository is private. Public repositories will receive a zero on the assignment.
- If you are unsure who your class graders are, ask your instructor or refer to the day 1 slide deck.
- Upload the code for all of the following prompts to your repository.
- Submit a URL link to your repository below.

<br><br>

### Requirements

<br>

Take the projects from the previous labs. Add circuit breakers to each and externalize the configurations.

