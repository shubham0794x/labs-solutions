INSERT INTO book VALUES (12345, 'Harry Potter', 'JK Rowling', 'Fantasy');
